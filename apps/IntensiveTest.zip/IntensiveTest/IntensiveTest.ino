#define FREQ 1000
#define DELAY ((1/FREQ)*10*10*10)
#define INPPIN1 A0
#define INPPIN2 A1

int k = 0;

void setup() {
  pinMode(A0, INPUT);
  pinMode(A1, INPUT);
  Serial.begin(1000000);
  tone(3, 2000);
}

void loop() {
  //if (k <= 24){Serial.println(analogRead(A1)); k+=1;}
  Serial.print(analogRead(A0));
  Serial.print(" ");
  Serial.print(analogRead(A1));
  Serial.println();
  delay(0.125);
}